import functions_framework

import os
from google.cloud import bigquery

def append_csv_to_bigquery(bucket_name, file_name):
     
    # Set BigQuery details
    project_id = 'possible-dream-433814-b4'  
    dataset_id = 'siri_dstest1'  
    table_id = file_name.rsplit('_', 1)[0]    

    # Create a BigQuery client
    client = bigquery.Client(project=project_id)

    # Define the URI for the CSV file in GCS
    gcs_uri = f'gs://{bucket_name}/{file_name}'

    # Configure the load job
    job_config = bigquery.LoadJobConfig(
        source_format=bigquery.SourceFormat.CSV,
        skip_leading_rows=1,  # Skip the header row
        autodetect=True,       # Automatically detect the schema
        write_disposition=bigquery.WriteDisposition.WRITE_APPEND  # Append to the table
    )

    # Start the load job
    load_job = client.load_table_from_uri(
        gcs_uri,
        f"{project_id}.{dataset_id}.{table_id}",
        job_config=job_config
    )

    # Wait for the job to complete
    load_job.result()

    print(f"Appended {load_job.output_rows} rows from {file_name} to {dataset_id}.{table_id}.")


# Triggered by a change in a storage bucket
@functions_framework.cloud_event
def hello_gcs(cloud_event):
    data = cloud_event.data

    event_id = cloud_event["id"]
    event_type = cloud_event["type"]

    bucket = data["bucket"]
    name = data["name"]
    metageneration = data["metageneration"]
    timeCreated = data["timeCreated"]
    updated = data["updated"]

    print(f"Event ID: {event_id}")
    print(f"Event type: {event_type}")
    print(f"Bucket: {bucket}")
    print(f"File: {name}")
    print(f"Metageneration: {metageneration}")
    print(f"Created: {timeCreated}")
    print(f"Updated: {updated}")
    
    append_csv_to_bigquery(bucket, name)
